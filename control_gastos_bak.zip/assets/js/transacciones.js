console.log("transacciones.js cargado");

async function cargarTransacciones() {
    const resp = await fetch("api_transacciones.php");
    const data = await resp.json();

    console.log("Transacciones recibidas:", data);

    let tbody = document.querySelector("#tablaTransacciones tbody");
    tbody.innerHTML = "";

    if (!Array.isArray(data)) {
        tbody.innerHTML = "<tr><td colspan='6'>Error cargando datos</td></tr>";
        return;
    }

    data.forEach(t => {
        tbody.innerHTML += `
        <tr>
            <td>${t.fecha}</td>
            <td>${t.descripcion ?? ""}</td>
            <td>${t.categoria ?? "-"}</td>
            <td>${t.subcategoria ?? "-"}</td>
            <td>${t.monto} €</td>
            <td>${t.tipo}</td>
            <td class="text-right">
                <button class="btn btn-link btn-sm edit-btn" data-id="{{id}}">
                    <i class="icon icon-edit"></i>
                </button>
                <button class="btn btn-link btn-sm delete-btn" data-id="{{id}}">
                    <i class="icon icon-delete"></i>
                </button>
            </td>

        </tr>`;
    });
}

document.addEventListener("DOMContentLoaded", cargarTransacciones);

async function eliminarTransaccion(id) {

    if (!confirm("¿Seguro que quieres eliminar esta transacción?")) return;

    let resp = await fetch("api_eliminar_transaccion.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ id })
    });

    let json = await resp.json();

    if (json.ok) {
        alert("Transacción eliminada");
        cargarTransacciones(); // Recargar la tabla sin refrescar página
    } else {
        alert("Error: " + json.error);
    }
}
function editarTransaccion(id) {
    // Esto lo implementaremos en el paso siguiente
    // Por ahora mostramos mensaje para confirmar que funciona
    alert("Editar transacción " + id);
}
